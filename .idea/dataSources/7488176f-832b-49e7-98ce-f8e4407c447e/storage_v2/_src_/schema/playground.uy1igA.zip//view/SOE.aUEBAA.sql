create view SOE as
select `playground`.`주문`.`인사번호`    AS `인사번호`,
       `playground`.`주문`.`주문번호`    AS `주문번호`,
       `playground`.`주문`.`주문일`     AS `주문일`,
       `playground`.`주문`.`납기일`     AS `납기일`,
       `playground`.`주문`.`고객번호`    AS `고객번호`,
       `playground`.`운송`.`운송ID`    AS `운송ID`,
       `playground`.`운송`.`운송이름`    AS `운송이름`,
       `playground`.`운송`.`담당자전화번호` AS `담당자전화번호`,
       `playground`.`직원`.`주민등록번호`  AS `주민등록번호`,
       `playground`.`직원`.`성명`      AS `성명`,
       `playground`.`직원`.`소속부서`    AS `소속부서`,
       `playground`.`직원`.`직책`      AS `직책`,
       `playground`.`직원`.`입사일`     AS `입사일`
from ((`playground`.`주문` join `playground`.`운송` on (`playground`.`주문`.`주문번호` = `playground`.`운송`.`주문번호`))
         join `playground`.`직원` on (`playground`.`주문`.`인사번호` = `playground`.`직원`.`인사번호`));

