create view 제품1 as
select `playground`.`sales_products`.`sprdid`    AS `sprdid`,
       `playground`.`sales_products`.`invent`    AS `invent`,
       `playground`.`sales_products`.`sprdmaker` AS `sprdmaker`
from `playground`.`sales_products`;

