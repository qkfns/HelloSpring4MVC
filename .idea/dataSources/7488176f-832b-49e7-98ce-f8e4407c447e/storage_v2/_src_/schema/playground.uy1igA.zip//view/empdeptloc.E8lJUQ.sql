create view empdeptloc as
select `playground`.`DEPARTMENTS`.`location_id`     AS `location_id`,
       `playground`.`EMPLOYEES`.`department_id`     AS `department_id`,
       `playground`.`EMPLOYEES`.`employee_id`       AS `employee_id`,
       `playground`.`EMPLOYEES`.`first_name`        AS `first_name`,
       `playground`.`EMPLOYEES`.`last_name`         AS `last_name`,
       `playground`.`EMPLOYEES`.`email`             AS `email`,
       `playground`.`EMPLOYEES`.`phone_number`      AS `phone_number`,
       `playground`.`EMPLOYEES`.`hire_date`         AS `hire_date`,
       `playground`.`EMPLOYEES`.`job_id`            AS `job_id`,
       `playground`.`EMPLOYEES`.`salary`            AS `salary`,
       `playground`.`EMPLOYEES`.`commission_pct`    AS `commission_pct`,
       `playground`.`EMPLOYEES`.`manager_id`        AS `manager_id`,
       `playground`.`DEPARTMENTS`.`department_name` AS `department_name`,
       `playground`.`LOCATIONS`.`street_address`    AS `street_address`,
       `playground`.`LOCATIONS`.`postal_code`       AS `postal_code`,
       `playground`.`LOCATIONS`.`city`              AS `city`,
       `playground`.`LOCATIONS`.`state_province`    AS `state_province`,
       `playground`.`LOCATIONS`.`country_id`        AS `country_id`
from ((`playground`.`EMPLOYEES` join `playground`.`DEPARTMENTS` on (`playground`.`EMPLOYEES`.`department_id` =
                                                                    `playground`.`DEPARTMENTS`.`department_id`))
         join `playground`.`LOCATIONS`
              on (`playground`.`DEPARTMENTS`.`location_id` = `playground`.`LOCATIONS`.`location_id`));

