create view 제품3 as
select `playground`.`sales_products`.`sprdname`  AS `제품명`,
       `playground`.`sales_products`.`invent`    AS `재고량`,
       `playground`.`sales_products`.`sprdmaker` AS `제조업체`
from `playground`.`sales_products`;

